import type {
  BiomeId,
  CraftRecipe,
  ElementType,
  FurnitureDef,
  FurnitureKind,
  HabitatDef,
  HabitatId,
  HotbarSlot,
  Inventory,
  InventoryKey,
  QuestDef,
  Rarity,
  SlugInstance,
  SlugSpecies,
} from './types';

export const WORLD_W = 320;
export const WORLD_H = 320;
export const CHUNK_SIZE = 16;
export const TILE_PX = 28;
export const SPAWN_X = 160;
export const SPAWN_Y = 160;
export const MAX_ACTIVE_HOME_SLUGS = 6;
export const MAX_SLUGS_PER_HABITAT = 2;
export const MAX_HOME_FURNITURE = 32;
export const SHELTER_HOME_RADIUS = 16;
export const MAX_SLUG_LEVEL = 20;

export const HABITAT_DEFS: HabitatDef[] = [
  {
    id: 'habitat_thermal',
    name: 'Rincón Térmico',
    description: 'Zona cálida de brasas y piedra volcánica ideal para babosas de Fuego.',
    acceptedTypes: ['Fuego'],
    anchorX: SPAWN_X + 3,
    anchorY: SPAWN_Y - 1,
    accentColor: '#fb923c',
    floorTint: 'rgba(249, 115, 22, 0.22)',
  },
  {
    id: 'habitat_aquatic',
    name: 'Estanque Fresco',
    description: 'Rincón húmedo y cristalino pensado para babosas de Agua y Hielo.',
    acceptedTypes: ['Agua', 'Hielo'],
    anchorX: SPAWN_X - 3,
    anchorY: SPAWN_Y - 1,
    accentColor: '#38bdf8',
    floorTint: 'rgba(56, 189, 248, 0.22)',
  },
  {
    id: 'habitat_crystal',
    name: 'Rincón Cristalino',
    description: 'Cristales resonantes que recargan a babosas Eléctricas, de Energía y Luz.',
    acceptedTypes: ['Electrico', 'Energia', 'Luz'],
    anchorX: SPAWN_X - 1,
    anchorY: SPAWN_Y - 2,
    accentColor: '#facc15',
    floorTint: 'rgba(45, 212, 191, 0.20)',
  },
  {
    id: 'habitat_shadow',
    name: 'Rincón Sombrío',
    description: 'Penumbra serena con ecos oscuros adaptada a babosas de Sombra.',
    acceptedTypes: ['Sombra'],
    anchorX: SPAWN_X - 2,
    anchorY: SPAWN_Y + 2,
    accentColor: '#c084fc',
    floorTint: 'rgba(168, 85, 247, 0.22)',
  },
  {
    id: 'habitat_garden',
    name: 'Jardín Subterráneo',
    description: 'Musgo blando y tierra fértil para babosas de Planta y Tierra.',
    acceptedTypes: ['Planta', 'Tierra'],
    anchorX: SPAWN_X + 2,
    anchorY: SPAWN_Y + 2,
    accentColor: '#4ade80',
    floorTint: 'rgba(74, 222, 128, 0.20)',
  },
];

export const FURNITURE_DEFS: Record<FurnitureKind, FurnitureDef> = {
  nest: {
    kind: 'nest',
    name: 'Nido Acogedor',
    description: 'Refugio mullido donde las babosas recuperan energía más rápido.',
    comfortBonus: 12,
  },
  bed: {
    kind: 'bed',
    name: 'Cama del Refugio',
    description: 'Descanso profundo que aumenta la comodidad de la habitación.',
    comfortBonus: 15,
  },
  feeder: {
    kind: 'feeder',
    name: 'Comedero Subterráneo',
    description: 'Mantiene alimento fresco cerca y reduce la pérdida de saciedad.',
    comfortBonus: 12,
  },
  decor: {
    kind: 'decor',
    name: 'Lámpara de Cristal',
    description: 'Ilumina la estancia con luz suave y embellece el hogar.',
    comfortBonus: 10,
    emitsLight: true,
  },
};

export interface HomeFoodDef {
  key: InventoryKey;
  label: string;
  description: string;
  favoriteFor: ElementType[] | 'all';
}

export const HOME_FOOD_DEFS: HomeFoodDef[] = [
  {
    key: 'berries',
    label: 'Bayas',
    description: 'Alimento universal del subsuelo (+38 Saciedad).',
    favoriteFor: 'all',
  },
  {
    key: 'emberSnack',
    label: 'Bocado Ígneo',
    description: 'Favorito de Fuego y Tierra (+55 Saciedad, +5 Amistad).',
    favoriteFor: ['Fuego', 'Tierra'],
  },
  {
    key: 'frostNectar',
    label: 'Néctar Glacial',
    description: 'Favorito de Agua, Hielo y Luz (+55 Saciedad, +5 Amistad).',
    favoriteFor: ['Agua', 'Hielo', 'Luz'],
  },
  {
    key: 'core',
    label: 'Núcleo Energético',
    description: 'Favorito de Eléctrico, Energía y Sombra (+55 Saciedad, +5 Amistad).',
    favoriteFor: ['Electrico', 'Energia', 'Sombra'],
  },
];

export const ELEMENT_CHART: Record<ElementType, { strong: ElementType[]; weak: ElementType[]; color: string }> = {
  Fuego: { strong: ['Hielo', 'Planta'], weak: ['Agua', 'Tierra'], color: '#f97316' },
  Agua: { strong: ['Fuego', 'Tierra'], weak: ['Electrico', 'Planta'], color: '#38bdf8' },
  Electrico: { strong: ['Agua'], weak: ['Tierra'], color: '#facc15' },
  Hielo: { strong: ['Tierra', 'Planta', 'Energia'], weak: ['Fuego'], color: '#67e8f9' },
  Sombra: { strong: ['Luz', 'Energia'], weak: ['Luz'], color: '#a855f7' },
  Luz: { strong: ['Sombra'], weak: ['Sombra'], color: '#fde047' },
  Tierra: { strong: ['Electrico', 'Fuego'], weak: ['Agua', 'Hielo', 'Planta'], color: '#d97706' },
  Planta: { strong: ['Agua', 'Tierra'], weak: ['Fuego', 'Hielo'], color: '#4ade80' },
  Energia: { strong: ['Sombra', 'Electrico'], weak: ['Hielo'], color: '#2dd4bf' },
};

export const BIOME_INFO: Record<
  BiomeId,
  {
    name: string;
    subtitle: string;
    ambientHex: string;
    darknessAlpha: number;
    floorA: string;
    floorB: string;
    wall: string;
    accent: string;
    mapColor: string;
  }
> = {
  Verdes: {
    name: 'Cuevas Verdes',
    subtitle: 'Flora bioluminiscente, hongos y lagos subterráneos',
    ambientHex: '#0b201c',
    darknessAlpha: 0.28,
    floorA: '#2e4a3d',
    floorB: '#263e34',
    wall: '#3c4a49',
    accent: '#4ade80',
    mapColor: '#3b7556',
  },
  Magma: {
    name: 'Cavernas de Magma',
    subtitle: 'Roca volcánica, ríos de lava y fraguas antiguas',
    ambientHex: '#2a0d08',
    darknessAlpha: 0.34,
    floorA: '#4b2a22',
    floorB: '#3e221c',
    wall: '#5a362d',
    accent: '#fb923c',
    mapColor: '#9e4328',
  },
  Heladas: {
    name: 'Cuevas Heladas',
    subtitle: 'Cristales glaciales, nieve compacta y cámaras congeladas',
    ambientHex: '#0b1e2e',
    darknessAlpha: 0.24,
    floorA: '#35566f',
    floorB: '#2b475d',
    wall: '#5a7f9c',
    accent: '#67e8f9',
    mapColor: '#5fa4c4',
  },
  Sombrias: {
    name: 'Cavernas Sombrías',
    subtitle: 'Oscuridad densa, cristales de energía y secretos antiguos',
    ambientHex: '#0b0718',
    darknessAlpha: 0.62,
    floorA: '#27203d',
    floorB: '#1f1932',
    wall: '#3a3058',
    accent: '#c084fc',
    mapColor: '#674796',
  },
};

export const SPECIES_LIST: SlugSpecies[] = [
  // 9 species preserved from Bajoterra 3.0
  {
    id: 'infurnus',
    name: 'Infurnus',
    type: 'Fuego',
    rarity: 'Rara',
    icon: '🔥',
    color: '#ef4444',
    accent: '#fde047',
    baseHp: 56,
    baseAtk: 15,
    baseDef: 9,
    baseSpd: 11,
    evoName: 'Megamorph Infurnus',
    habitat: 'Verdes',
    lore: 'Babosa de llama noble capaz de encender túneles enteros con su impacto ígneo.',
    specialMoves: [
      { id: 'ignis', name: 'Impacto Ígneo', power: 1.35, energyCost: 4, cooldown: 1, effect: 'burn', description: 'Daño ígneo + quemadura por 2 turnos.' },
      { id: 'nova', name: 'Fulgor Solar', power: 1.75, energyCost: 7, cooldown: 3, effect: 'pierce', description: 'Ignora escudos enemigos.' },
    ],
  },
  {
    id: 'aquabeak',
    name: 'Aquabeak',
    type: 'Agua',
    rarity: 'Común',
    icon: '💧',
    color: '#0ea5e9',
    accent: '#bae6fd',
    baseHp: 64,
    baseAtk: 12,
    baseDef: 12,
    baseSpd: 10,
    evoName: 'Megamorph Aquabeak',
    habitat: 'Verdes',
    lore: 'Habita cerca de lagos subterráneos y dispara chorros de alta presión.',
    specialMoves: [
      { id: 'jet', name: 'Chorro Abisal', power: 1.3, energyCost: 4, cooldown: 1, description: 'Ataque preciso de agua comprimida.' },
      { id: 'veil', name: 'Manto Acuático', power: 0, energyCost: 5, cooldown: 2, effect: 'heal', description: 'Restaura 35% PS y limpia quemaduras.' },
    ],
  },
  {
    id: 'tazerling',
    name: 'Tazerling',
    type: 'Electrico',
    rarity: 'Común',
    icon: '⚡',
    color: '#eab308',
    accent: '#fef08a',
    baseHp: 50,
    baseAtk: 16,
    baseDef: 8,
    baseSpd: 16,
    evoName: 'Megamorph Tazerling',
    habitat: 'Verdes',
    lore: 'Velocidad relámpago; ideal para aturdir rivales antes de que ataquen.',
    specialMoves: [
      { id: 'volt', name: 'Pulso Voltio', power: 1.35, energyCost: 4, cooldown: 1, effect: 'stun', description: 'Chispa veloz con probabilidad de aturdir.' },
      { id: 'storm', name: 'Sobrecarga', power: 1.8, energyCost: 7, cooldown: 3, description: 'Descarga eléctrica de alto voltaje.' },
    ],
  },
  {
    id: 'frostcrawler',
    name: 'Frostcrawler',
    type: 'Hielo',
    rarity: 'Común',
    icon: '❄️',
    color: '#22d3ee',
    accent: '#e0f2fe',
    baseHp: 60,
    baseAtk: 14,
    baseDef: 11,
    baseSpd: 9,
    evoName: 'Megamorph Frostcrawler',
    habitat: 'Heladas',
    lore: 'Sus agujas de escarcha congelan el suelo y frenan a los depredadores.',
    specialMoves: [
      { id: 'needle', name: 'Aguja de Hielo', power: 1.3, energyCost: 4, cooldown: 1, effect: 'chill', description: 'Enfría al rival reduciendo su ataque.' },
      { id: 'glacier', name: 'Muro Glacial', power: 0.6, energyCost: 5, cooldown: 2, effect: 'shield', description: 'Daño ligero + escudo protector.' },
    ],
  },
  {
    id: 'doc',
    name: 'Doc',
    type: 'Luz',
    rarity: 'Rara',
    icon: '✨',
    color: '#facc15',
    accent: '#ffffff',
    baseHp: 60,
    baseAtk: 11,
    baseDef: 12,
    baseSpd: 12,
    evoName: 'Megamorph Doc',
    habitat: 'Verdes',
    lore: 'Babosa sanadora legendaria por purificar energía corrupta y curar aliados.',
    specialMoves: [
      { id: 'healray', name: 'Destello Sanador', power: 0, energyCost: 4, cooldown: 1, effect: 'heal', description: 'Recupera 42% PS propios.' },
      { id: 'prism', name: 'Rayo Prisma', power: 1.45, energyCost: 6, cooldown: 2, effect: 'pierce', description: 'Luz pura eficaz contra sombras.' },
    ],
  },
  {
    id: 'darkfurnus',
    name: 'Darkfurnus',
    type: 'Sombra',
    rarity: 'Épica',
    icon: '🌑',
    color: '#7e22ce',
    accent: '#e9d5ff',
    baseHp: 62,
    baseAtk: 17,
    baseDef: 10,
    baseSpd: 13,
    evoName: 'Megamorph Darkfurnus',
    habitat: 'Sombrias',
    lore: 'Corrompida por oscuridad pura; drena vitalidad con llamas sombrías.',
    specialMoves: [
      { id: 'umbral', name: 'Llama Umbría', power: 1.4, energyCost: 5, cooldown: 1, effect: 'burn', description: 'Fuego sombrío que quema al objetivo.' },
      { id: 'siphon', name: 'Sifón Nocturno', power: 1.3, energyCost: 6, cooldown: 2, effect: 'drain', description: 'Inflige daño y absorbe 40% en PS.' },
    ],
  },
  {
    id: 'flaringo',
    name: 'Flaringo',
    type: 'Fuego',
    rarity: 'Rara',
    icon: '🦩',
    color: '#fb7185',
    accent: '#fef08a',
    baseHp: 58,
    baseAtk: 16,
    baseDef: 9,
    baseSpd: 14,
    evoName: 'Megamorph Flaringo',
    habitat: 'Magma',
    lore: 'Ágil criatura de las cavernas de magma que ejecuta ráfagas carmesí acrobáticas.',
    specialMoves: [
      { id: 'crimson', name: 'Ráfaga Carmesí', power: 1.45, energyCost: 4, cooldown: 1, effect: 'burn', description: 'Chorro rápido con rastro ardiente.' },
      { id: 'spiral', name: 'Espiral Ígnea', power: 1.75, energyCost: 7, cooldown: 3, description: 'Impacto giratorio de gran potencia.' },
    ],
  },
  {
    id: 'lariat',
    name: 'Lariat',
    type: 'Tierra',
    rarity: 'Común',
    icon: '🪨',
    color: '#b45309',
    accent: '#fde68a',
    baseHp: 72,
    baseAtk: 15,
    baseDef: 14,
    baseSpd: 8,
    evoName: 'Megamorph Lariat',
    habitat: 'Magma',
    lore: 'Robusta babosa de roca capaz de inmovilizar enemigos con su lazo sísmico.',
    specialMoves: [
      { id: 'lasso', name: 'Lazo Sísmico', power: 1.3, energyCost: 4, cooldown: 1, effect: 'stun', description: 'Atrapa y sacude al enemigo.' },
      { id: 'bastion', name: 'Bastión Pétreo', power: 0.7, energyCost: 5, cooldown: 2, effect: 'shield', description: 'Levanta armadura de roca dura.' },
    ],
  },
  {
    id: 'enigmo',
    name: 'Enigmo',
    type: 'Energia',
    rarity: 'Épica',
    icon: '🔮',
    color: '#14b8a6',
    accent: '#a7f3d0',
    baseHp: 56,
    baseAtk: 18,
    baseDef: 10,
    baseSpd: 15,
    evoName: 'Megamorph Enigmo',
    habitat: 'Sombrias',
    lore: 'Emite ondas psíquicas que revelan fisuras ocultas y desestabilizan defensas.',
    specialMoves: [
      { id: 'mind', name: 'Pulso Mental', power: 1.45, energyCost: 5, cooldown: 1, effect: 'pierce', description: 'Ondas que atraviesan escudos.' },
      { id: 'rift', name: 'Fisura Astral', power: 1.85, energyCost: 8, cooldown: 3, effect: 'stun', description: 'Explosión energética desorientadora.' },
    ],
  },

  // 6 Original Bajoterra 4.0 Species
  {
    id: 'musgacorn',
    name: 'Musgacorn',
    type: 'Planta',
    rarity: 'Común',
    icon: '🌿',
    color: '#22c55e',
    accent: '#bbf7d0',
    baseHp: 64,
    baseAtk: 12,
    baseDef: 12,
    baseSpd: 10,
    evoName: 'Megamorph Musgacorn',
    habitat: 'Verdes',
    lore: 'Simbiosis entre musgo luminoso y coraza; regenera su salud con esporas.',
    specialMoves: [
      { id: 'spore', name: 'Espora Vital', power: 1.0, energyCost: 4, cooldown: 1, effect: 'drain', description: 'Drena energía vegetal del enemigo.' },
      { id: 'thorn', name: 'Raíz Punzante', power: 1.5, energyCost: 6, cooldown: 2, description: 'Ataque firme de lianas subterráneas.' },
    ],
  },
  {
    id: 'piroclasto',
    name: 'Piroclasto',
    type: 'Fuego',
    rarity: 'Épica',
    icon: '🌋',
    color: '#dc2626',
    accent: '#fdba74',
    baseHp: 68,
    baseAtk: 18,
    baseDef: 12,
    baseSpd: 9,
    evoName: 'Megamorph Piroclasto',
    habitat: 'Magma',
    lore: 'Núcleo de obsidiana viva que libera erupciones tectónicas bajo presión.',
    specialMoves: [
      { id: 'eruption', name: 'Erupción Tectónica', power: 1.65, energyCost: 6, cooldown: 2, effect: 'burn', description: 'Explosión volcánica abrasadora.' },
      { id: 'magmaarmor', name: 'Corteza de Basalto', power: 0.75, energyCost: 5, cooldown: 2, effect: 'shield', description: 'Escudo volcánico de alta densidad.' },
    ],
  },
  {
    id: 'glaciomita',
    name: 'Glaciomita',
    type: 'Hielo',
    rarity: 'Rara',
    icon: '🧊',
    color: '#38bdf8',
    accent: '#f0f9ff',
    baseHp: 66,
    baseAtk: 15,
    baseDef: 13,
    baseSpd: 11,
    evoName: 'Megamorph Glaciomita',
    habitat: 'Heladas',
    lore: 'Esculpida en estalagmitas milenarias; domina ráfagas de ventisca cristalina.',
    specialMoves: [
      { id: 'blizzard', name: 'Ventisca Cristalina', power: 1.5, energyCost: 5, cooldown: 2, effect: 'chill', description: 'Congela al rival y baja su daño.' },
      { id: 'shard', name: 'Lanza de Escarcha', power: 1.3, energyCost: 4, cooldown: 1, effect: 'pierce', description: 'Fragmento afilado anti-escudo.' },
    ],
  },
  {
    id: 'voltrix',
    name: 'Voltrix',
    type: 'Electrico',
    rarity: 'Rara',
    icon: '💠',
    color: '#3b82f6',
    accent: '#fef08a',
    baseHp: 54,
    baseAtk: 17,
    baseDef: 9,
    baseSpd: 17,
    evoName: 'Megamorph Voltrix',
    habitat: 'Heladas',
    lore: 'Genera arcos voltaicos entre cristales congelados a velocidades extremas.',
    specialMoves: [
      { id: 'arc', name: 'Arco Voltaico', power: 1.45, energyCost: 4, cooldown: 1, effect: 'stun', description: 'Rayo encadenado de respuesta rápida.' },
      { id: 'rail', name: 'Cañón Estático', power: 1.8, energyCost: 7, cooldown: 3, effect: 'pierce', description: 'Disparo electromagnético perforante.' },
    ],
  },
  {
    id: 'umbrospect',
    name: 'Umbrospect',
    type: 'Sombra',
    rarity: 'Épica',
    icon: '👁️',
    color: '#9333ea',
    accent: '#f5d0fe',
    baseHp: 60,
    baseAtk: 19,
    baseDef: 10,
    baseSpd: 14,
    evoName: 'Megamorph Umbrospect',
    habitat: 'Sombrias',
    lore: 'Espectro de las profundidades que absorbe la luz y lanza eclipses abismales.',
    specialMoves: [
      { id: 'eclipse', name: 'Eclipse Abismal', power: 1.6, energyCost: 6, cooldown: 2, effect: 'chill', description: 'Debilita la ofensiva del oponente.' },
      { id: 'voiddrain', name: 'Vacío Devorador', power: 1.35, energyCost: 5, cooldown: 2, effect: 'drain', description: 'Roba vitalidad desde las sombras.' },
    ],
  },
  {
    id: 'aetherion',
    name: 'Aetherion',
    type: 'Energia',
    rarity: 'Legendaria',
    icon: '🌟',
    color: '#2dd4bf',
    accent: '#fef08a',
    baseHp: 74,
    baseAtk: 20,
    baseDef: 14,
    baseSpd: 16,
    evoName: 'Megamorph Aetherion',
    habitat: 'Sombrias',
    lore: 'Reliquia viviente del subsuelo profundo; armoniza todos los cristales de energía.',
    specialMoves: [
      { id: 'prisma', name: 'Singularidad Prisma', power: 1.9, energyCost: 7, cooldown: 3, effect: 'pierce', description: 'Explosión prismática imparable.' },
      { id: 'resonance', name: 'Resonancia Viva', power: 0, energyCost: 5, cooldown: 2, effect: 'heal', description: 'Restaura 45% PS y carga escudo.' },
    ],
  },
];

export const HOTBAR_SLOTS: HotbarSlot[] = [
  { id: 'mine', label: 'Pico', keyHint: '1' },
  { id: 'torch', label: 'Antorcha', keyHint: '2', itemKey: 'torches' },
  { id: 'wall', label: 'Pared', keyHint: '3', itemKey: 'walls' },
  { id: 'floor', label: 'Suelo', keyHint: '4', itemKey: 'floors' },
  { id: 'door', label: 'Puerta', keyHint: '5', itemKey: 'doors' },
  { id: 'station', label: 'Estación', keyHint: '6', itemKey: 'stations' },
  { id: 'berry', label: 'Baya', keyHint: '7', itemKey: 'berries' },
  { id: 'pulse', label: 'Pulso', keyHint: '8' },
];

export const CRAFT_RECIPES: CraftRecipe[] = [
  {
    id: 'torches',
    name: '3× Antorchas',
    description: 'Iluminan cavernas oscuras y alejan emboscadas cercanas.',
    outputKey: 'torches',
    outputQty: 3,
    cost: { wood: 1, ore: 1 },
  },
  {
    id: 'walls',
    name: '3× Paredes de Refugio',
    description: 'Bloques reforzados para proteger tu base subterránea.',
    outputKey: 'walls',
    outputQty: 3,
    cost: { stone: 2 },
  },
  {
    id: 'floors',
    name: '3× Suelos de Refugio',
    description: 'Pavimento de madera tratada para ampliar estancias.',
    outputKey: 'floors',
    outputQty: 3,
    cost: { wood: 2 },
  },
  {
    id: 'doors',
    name: '1× Puerta Blindada',
    description: 'Se abre y cierra al interactuar para controlar accesos.',
    outputKey: 'doors',
    outputQty: 1,
    cost: { wood: 2, ore: 2 },
  },
  {
    id: 'core',
    name: '1× Núcleo de Energía',
    description: 'Recarga 8 puntos de energía en combate.',
    outputKey: 'core',
    outputQty: 1,
    cost: { ore: 2, wood: 1 },
  },
  {
    id: 'capsules',
    name: '2× Cilindros de Captura',
    description: 'Cápsulas estándar para capturar babosas salvajes.',
    outputKey: 'capsules',
    outputQty: 2,
    cost: { ore: 3, wood: 1 },
  },
  {
    id: 'masterCapsules',
    name: '1× Cilindro Maestro',
    description: 'Alta tasa de captura incluso en babosas épicas.',
    outputKey: 'masterCapsules',
    outputQty: 1,
    cost: { crystal: 2, ore: 3, core: 1 },
  },
  {
    id: 'stations',
    name: '1× Estación de Recarga',
    description: 'Colócala en cualquier bioma para sanar a todo tu equipo.',
    outputKey: 'stations',
    outputQty: 1,
    cost: { stone: 4, crystal: 2, core: 1 },
  },
  {
    id: 'elixirs',
    name: '1× Elixir Megamorph',
    description: 'Aumenta +25 amistad y +35 EXP a tu babosa activa.',
    outputKey: 'elixirs',
    outputQty: 1,
    cost: { shadowShard: 2, core: 1, berries: 2 },
  },
  {
    id: 'emberSnack',
    name: '2× Bocado Ígneo',
    description: 'Alimento favorito para babosas de Fuego y Tierra en el hogar.',
    outputKey: 'emberSnack',
    outputQty: 2,
    cost: { berries: 1, ore: 1 },
  },
  {
    id: 'frostNectar',
    name: '2× Néctar Glacial',
    description: 'Alimento favorito para babosas de Agua, Hielo y Luz en el hogar.',
    outputKey: 'frostNectar',
    outputQty: 2,
    cost: { berries: 1, crystal: 1 },
  },
  {
    id: 'nest',
    name: '1× Nido Acogedor',
    description: 'Mobiliario del hogar que acelera el descanso de tus babosas.',
    outputKey: 'nest',
    outputQty: 1,
    cost: { wood: 3, berries: 1 },
  },
  {
    id: 'bed',
    name: '1× Cama del Refugio',
    description: 'Aporta gran comodidad (+15) y mejora la recuperación en el hogar.',
    outputKey: 'bed',
    outputQty: 1,
    cost: { wood: 4, stone: 2 },
  },
  {
    id: 'feeder',
    name: '1× Comedero Subterráneo',
    description: 'Mobiliario del hogar que ralentiza la bajada de hambre.',
    outputKey: 'feeder',
    outputQty: 1,
    cost: { wood: 2, ore: 2 },
  },
  {
    id: 'decor',
    name: '1× Lámpara de Cristal',
    description: 'Ilumina habitaciones del hogar y suma comodidad ambiental.',
    outputKey: 'decor',
    outputQty: 1,
    cost: { stone: 2, crystal: 1 },
  },
  {
    id: 'torches_magma',
    name: '4× Antorchas de Magma',
    description: 'Antorchas de larga duración forjadas con carbón ígneo y raíces.',
    outputKey: 'torches',
    outputQty: 4,
    cost: { rootWood: 1, magmaCoal: 1 },
  },
  {
    id: 'emberSnack_coal',
    name: '3× Bocado Ígneo Reforzado',
    description: 'Prepara alimento favorito térmico aprovechando carbón de magma.',
    outputKey: 'emberSnack',
    outputQty: 3,
    cost: { berries: 1, magmaCoal: 1 },
  },
  {
    id: 'frostNectar_ice',
    name: '3× Néctar Glacial Puro',
    description: 'Prepara alimento favorito helado con cristales de hielo.',
    outputKey: 'frostNectar',
    outputQty: 3,
    cost: { berries: 1, iceCrystal: 1 },
  },
  {
    id: 'capsules_copper',
    name: '3× Cilindros Térmicos',
    description: 'Cilindros resistentes ensamblados con cobre térmico y carbón.',
    outputKey: 'capsules',
    outputQty: 3,
    cost: { thermalCopper: 2, magmaCoal: 1 },
  },
  {
    id: 'masterCapsules_quartz',
    name: '1× Cilindro Maestro de Cuarzo',
    description: 'Cápsula de alta precisión forjada con cuarzo azul y hierro oscuro.',
    outputKey: 'masterCapsules',
    outputQty: 1,
    cost: { blueQuartz: 2, darkIron: 2 },
  },
  {
    id: 'walls_iron',
    name: '5× Paredes de Hierro Oscuro',
    description: 'Muros subterráneos reforzados para proteger estancias del refugio.',
    outputKey: 'walls',
    outputQty: 5,
    cost: { darkIron: 2, stone: 2 },
  },
  {
    id: 'floors_root',
    name: '4× Suelos de Raíz Viva',
    description: 'Tarima orgánica cálida ideal para ampliar hábitats.',
    outputKey: 'floors',
    outputQty: 4,
    cost: { rootWood: 2 },
  },
  {
    id: 'elixirs_neon',
    name: '1× Elixir Luminoso',
    description: 'Destilado de hongos de neón y cuarzo azul para amistad y Megamorph.',
    outputKey: 'elixirs',
    outputQty: 1,
    cost: { neonMushroom: 3, blueQuartz: 1 },
  },
  {
    id: 'decor_quartz',
    name: '1× Lámpara de Cuarzo Azul',
    description: 'Luminaria del hogar tallada con cuarzo azul y madera de raíces.',
    outputKey: 'decor',
    outputQty: 1,
    cost: { blueQuartz: 2, rootWood: 1 },
  },
  {
    id: 'evoStone_craft',
    name: '1× Piedra Evolutiva Elemental',
    description: 'Catalizador elemental alternativo para despertar Megamorph.',
    outputKey: 'evoStone',
    outputQty: 1,
    cost: { magmaCoal: 2, iceCrystal: 2, neonMushroom: 2, blueQuartz: 1 },
  },
];

export const QUEST_LIST: QuestDef[] = [
  {
    id: 'q_main_1',
    category: 'principal',
    title: '01. Primeros Ecos del Subsuelo',
    description: 'Reúne 10 minerales en las Cuevas Verdes y coloca 2 antorchas.',
    metric: 'oreMined',
    goal: 10,
    extraConditions: [{ metric: 'torchesPlaced', goal: 2, label: 'Antorchas' }],
    rewardText: '+6 minerales · +3 cilindros · +40 EXP',
    rewards: { ore: 6, capsules: 3, xp: 40 },
  },
  {
    id: 'q_main_2',
    category: 'principal',
    title: '02. Constructor del Refugio',
    description: 'Construye 4 bloques de refugio (paredes, suelos o puertas) y mejora el refugio al Nivel 2.',
    metric: 'structuresBuilt',
    goal: 4,
    extraConditions: [{ metric: 'shelterTier', goal: 2, label: 'Refugio Nv.' }],
    rewardText: '+4 madera · +2 núcleos · +50 EXP',
    rewards: { wood: 4, core: 2, xp: 50 },
  },
  {
    id: 'q_main_3',
    category: 'principal',
    title: '03. Fronteras Elementales',
    description: 'Descubre los 4 biomas principales del mundo subterráneo.',
    metric: 'biomesFound',
    goal: 4,
    rewardText: '+2 Cilindros Maestros · Habilidad Resistencia Térmica',
    rewards: { masterCapsules: 2, crystal: 3, xp: 90, perk: 'Resistencia Térmica' },
  },
  {
    id: 'q_main_4',
    category: 'principal',
    title: '04. Guardianes del Abismo',
    description: 'Derrota a 2 Jefes de Bioma o al Comandante de Blakk.',
    metric: 'bossesDefeated',
    goal: 2,
    rewardText: '+3 Reliquias · +2 Elixires Megamorph · Habilidad Vínculo Maestro',
    rewards: { relics: 3, elixirs: 2, xp: 150, perk: 'Vínculo Maestro' },
  },
  {
    id: 'q_side_1',
    category: 'secundaria',
    title: 'Iluminando la Oscuridad',
    description: 'Coloca 5 antorchas en túneles subterráneos.',
    metric: 'torchesPlaced',
    goal: 5,
    rewardText: '+4 antorchas · +2 bayas',
    rewards: { torches: 4, berries: 2, xp: 30 },
  },
  {
    id: 'q_side_2',
    category: 'secundaria',
    title: 'Cazador de Tesoros',
    description: 'Encuentra y abre 4 cofres en ruinas o cámaras secretas.',
    metric: 'chestsOpened',
    goal: 4,
    rewardText: '+2 cristales · +1 Cilindro Maestro',
    rewards: { crystal: 2, masterCapsules: 1, xp: 60 },
  },
  {
    id: 'q_side_3',
    category: 'secundaria',
    title: 'Coleccionista Vivo',
    description: 'Registra 6 especies distintas capturadas en tu Babosapedia.',
    metric: 'speciesCaptured',
    goal: 6,
    rewardText: '+3 cilindros · +2 núcleos · Habilidad Visión de Cristal',
    rewards: { capsules: 3, core: 2, xp: 80, perk: 'Visión de Cristal' },
  },
  {
    id: 'q_side_4',
    category: 'secundaria',
    title: 'Nueva Generación',
    description: 'Incuba y eclosiona 1 babosa en la Incubadora del Refugio.',
    metric: 'eggsHatched',
    goal: 1,
    rewardText: '+1 Elixir Megamorph · +3 bayas',
    rewards: { elixirs: 1, berries: 3, xp: 65 },
  },
  {
    id: 'q_side_5',
    category: 'secundaria',
    title: 'Despertar Megamorph',
    description: 'Alcanza la evolución Megamorph con al menos 1 babosa.',
    metric: 'megaUnlocked',
    goal: 1,
    rewardText: '+3 cristales sombríos · +2 Reliquias',
    rewards: { shadowShard: 3, relics: 2, xp: 120 },
  },
];

export const BOSS_DEFINITIONS = [
  {
    id: 'boss_magma',
    name: 'Titán Piroclasto',
    speciesId: 'piroclasto',
    biome: 'Magma' as BiomeId,
    x: 162,
    y: 252,
    level: 6,
    icon: '🌋',
  },
  {
    id: 'boss_ice',
    name: 'Reina Glaciomita',
    speciesId: 'glaciomita',
    biome: 'Heladas' as BiomeId,
    x: 42,
    y: 162,
    level: 6,
    icon: '🧊',
  },
  {
    id: 'boss_shadow',
    name: 'Espectro del Abismo',
    speciesId: 'umbrospect',
    biome: 'Sombrias' as BiomeId,
    x: 274,
    y: 158,
    level: 8,
    icon: '👁️',
  },
  {
    id: 'boss_blakk',
    name: 'Comandante Blakk',
    speciesId: 'darkfurnus',
    biome: 'Sombrias' as BiomeId,
    x: 276,
    y: 54,
    level: 9,
    icon: '🦹',
  },
];

export function createDefaultInventory(): Inventory {
  return {
    ore: 4,
    wood: 6,
    stone: 10,
    crystal: 1,
    shadowShard: 0,
    berries: 4,
    core: 2,
    capsules: 4,
    masterCapsules: 0,
    torches: 4,
    walls: 4,
    floors: 4,
    doors: 1,
    stations: 0,
    elixirs: 0,
    relics: 0,
    emberSnack: 0,
    frostNectar: 0,
    nest: 0,
    bed: 0,
    feeder: 0,
    decor: 0,
    rootWood: 0,
    magmaCoal: 0,
    thermalCopper: 0,
    iceCrystal: 0,
    blueQuartz: 0,
    darkIron: 0,
    neonMushroom: 0,
    evoStone: 0,
  };
}

export function getSpecies(id: string): SlugSpecies {
  return SPECIES_LIST.find((s) => s.id === id) || SPECIES_LIST[0];
}

export function getHabitatDef(id: HabitatId): HabitatDef {
  return HABITAT_DEFS.find((h) => h.id === id) || HABITAT_DEFS[0];
}

export function isSpeciesCompatibleWithHabitat(speciesId: string, habitatId: HabitatId): boolean {
  const sp = getSpecies(speciesId);
  const hab = getHabitatDef(habitatId);
  return hab.acceptedTypes.includes(sp.type);
}

export function getCompatibleHabitatsForSpecies(speciesId: string): HabitatDef[] {
  const sp = getSpecies(speciesId);
  return HABITAT_DEFS.filter((h) => h.acceptedTypes.includes(sp.type));
}

export function getFavoriteFoodForSpecies(speciesId: string): HomeFoodDef {
  const sp = getSpecies(speciesId);
  return (
    HOME_FOOD_DEFS.find((f) => Array.isArray(f.favoriteFor) && f.favoriteFor.includes(sp.type)) ||
    HOME_FOOD_DEFS[0]
  );
}

let slugUidSeq = 1;

export function createSlugInstance(
  id: string,
  level = 1,
  opts?: { isBred?: boolean; bonusTrait?: string }
): SlugInstance {
  const sp = getSpecies(id);
  const clampedLevel = Math.max(1, Math.min(MAX_SLUG_LEVEL, Math.floor(Number.isFinite(level) ? level : 1)));
  const traitHp = opts?.bonusTrait === 'Vitalidad +' ? 10 : 0;
  const traitAtk = opts?.bonusTrait === 'Potencia +' ? 3 : 0;
  const traitSpd = opts?.bonusTrait === 'Velocidad +' ? 3 : 0;
  const maxHp = sp.baseHp + clampedLevel * 6 + traitHp;
  const maxEnergy = 14 + Math.floor(clampedLevel * 1.5);
  return {
    uid: `${sp.id}_${Date.now().toString(36)}_${slugUidSeq++}_${Math.random().toString(36).slice(2, 6)}`,
    id: sp.id,
    name: sp.name,
    type: sp.type,
    rarity: sp.rarity,
    icon: sp.icon,
    level: clampedLevel,
    xp: 0,
    hp: maxHp,
    maxHp,
    energy: maxEnergy,
    maxEnergy,
    atk: sp.baseAtk + Math.floor(clampedLevel * 2.1) + traitAtk,
    def: sp.baseDef + Math.floor(clampedLevel * 1.4),
    spd: sp.baseSpd + Math.floor(clampedLevel * 1.2) + traitSpd,
    bond: opts?.isBred ? 35 : 22,
    mega: false,
    isBred: opts?.isBred,
    bonusTrait: opts?.bonusTrait,
    moveMastery: [0, 0],
  };
}

export function getElementMultiplier(atkType: ElementType, defType: ElementType): number {
  const entry = ELEMENT_CHART[atkType];
  if (!entry) return 1;
  if (entry.strong.includes(defType)) return 1.75;
  if (entry.weak.includes(defType)) return 0.65;
  return 1;
}

export const RARITY_WEIGHTS: Record<Rarity, number> = {
  Común: 55,
  Rara: 28,
  Épica: 13,
  Legendaria: 4,
};

export function pickWeightedSpeciesByBiome(biome: BiomeId, rng: () => number = Math.random): SlugSpecies {
  const pool = SPECIES_LIST.filter((s) => s.habitat === biome);
  const candidates = pool.length > 0 ? pool : SPECIES_LIST;
  const totalWeight = candidates.reduce((acc, sp) => acc + (RARITY_WEIGHTS[sp.rarity] ?? 10), 0);
  let roll = rng() * totalWeight;
  for (const sp of candidates) {
    roll -= RARITY_WEIGHTS[sp.rarity] ?? 10;
    if (roll <= 0) return sp;
  }
  return candidates[candidates.length - 1];
}
